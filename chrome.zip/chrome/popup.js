$(document).ready(function(){
		$(".historylist>tbody>tr").each(function (index) {

			var qishu = $(this).find("a").text();
			var dates = $(this).find("td").eq(1).text();
			var redBalls = $(this).find(".redBalls").html();
			var blueBalls = $(this).find(".blueBalls").html();
			var ball = {
				"qishu" : qishu,
				"dates" : dates,
				"redBalls" : redBalls,
				"blueBalls" : blueBalls
			};
			var s=j=0;
			
			
			$.ajax({
				url : "http://app.store/frontend/lottery/gdata",
				dataType : "json",
				type : "get",
				data : ball,
				success: function(msg){
					s++;
					 console.log( "Data Saved: " + msg );
					},
				error:function(){
					j++;
				}
				complete:function(){
					if(s+j==30){
						window.localtion.href = "/lottery/index";
					}
				}


			});

		});
	
});
